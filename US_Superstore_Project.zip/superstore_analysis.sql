#CREATE database superstore;

# Checking all tables:
SELECT * FROM superstore.orders;
SELECT * FROM superstore.returns;
SELECT * FROM superstore.people;


######## Data Cleaning ########

#(1) Initial column name change in orders table
ALTER TABLE `superstore`.`orders` 
CHANGE COLUMN `Row ID` `Row_ID` INT NULL DEFAULT NULL,
CHANGE COLUMN `Order ID` `Order_ID` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Order Date` `Order_Date` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Ship Date` `Ship_Date` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Ship Mode` `Ship_Mode` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Customer ID` `Customer_ID` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Customer Name` `Customer_Name` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Postal Code` `Postal_Code` INT NULL DEFAULT NULL,
CHANGE COLUMN `Product ID` `Product_ID` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Sub-Category` `Sub_Category` TEXT NULL DEFAULT NULL,
CHANGE COLUMN `Product Name` `Product_Name` TEXT NULL DEFAULT NULL ;

## Checking all tables for blanks.
# Result: No column has missing or null values.
SELECT *
FROM returns
WHERE Order_ID IS NULL OR Returned IS NULL;

SELECT * 
FROM orders
WHERE Order_ID IS NULL
OR  Order_Date IS NULL
OR Ship_Date IS NULL
OR Ship_Mode IS NULL
OR Customer_ID IS NULL
OR Customer_Name IS NULL
OR Segment IS NULL
OR Country IS NULL
OR State IS NULL
OR Postal_Code IS NULL
OR Region IS NULL
OR Product_ID IS NULL
OR Category IS NULL 
OR Sub_Category IS NULL
OR Product_Name IS NULL
OR Sales IS NULL
OR Quantity IS NULL
OR Discount IS NULL
OR Profit IS NULL;

SELECT *
FROM people 
WHERE Person IS NULL
OR Region IS NULL;

## Checking all tables for duplicates.
# Result: No duplicates were found.
SELECT *, COUNT(*) AS Duplicate_Count
FROM orders
GROUP BY 
    Row_ID, Order_ID, Order_Date, Ship_Date, Ship_Mode, Customer_ID, Customer_Name, 
    Segment, Country, City, State, Postal_Code, Region, Product_ID, Category, 
    Sub_Category, Product_Name, Sales, Quantity, Discount, Profit
HAVING COUNT(*) > 1;

SELECT *, COUNT(*) AS Duplicate_Count
FROM people
GROUP BY
	person, region
HAVING COUNT(*) > 1;

SELECT *, COUNT(*) As Duplicate_Count
FROM returns
GROUP BY
	Returned, Order_ID
HAVING COUNT(*) > 1;


## Performing necessary alterations on tables:
# (1) Column names 

ALTER TABLE superstore.returns
CHANGE COLUMN `Order ID` `Order_ID` TEXT NULL DEFAULT NULL;

# This step was done above for the orders table

# (2) Data types
# Change order_id(varchar100 - in orders and returns tables), customer_id (varchar50), product_id (varchar100)
ALTER TABLE `orders`
CHANGE COLUMN `Order_ID` `Order_ID` VARCHAR(100),
CHANGE COLUMN `Customer_ID` `Customer_ID` VARCHAR(50),
CHANGE COLUMN `Product_ID` `Product_ID` VARCHAR(100);

ALTER TABLE returns
CHANGE COLUMN Order_ID Order_ID VARCHAR(100);

# Adding new columns, converting text-based dates into standardised date format and replacing old columns order_date (text) and ship_date (text) into date.  
ALTER TABLE orders
ADD COLUMN Order_Date_Converted DATE,
ADD COLUMN Ship_Date_Converted DATE;

UPDATE orders
SET
	Order_Date_Converted = STR_TO_DATE(Order_Date, '%d/%m/%Y'),
    Ship_Date_Converted = STR_TO_DATE(Ship_Date, '%d/%m/%Y');

ALTER TABLE orders
DROP COLUMN Order_Date,
DROP COLUMN Ship_Date,
CHANGE COLUMN Order_Date_Converted Order_Date DATE,
CHANGE COLUMN Ship_Date_Converted Ship_Date DATE;

SELECT *
FROM orders
WHERE Order_Date IS NULL OR Ship_Date IS NULL;  # Ensuring no rows failed to convert

# Adding new columns, substring function applied to customer_name.
ALTER TABLE orders
ADD COLUMN First_Name VARCHAR(100),
ADD COLUMN Last_Name VARCHAR(100);

UPDATE orders
SET
	First_Name = SUBSTRING_INDEX(Customer_Name, ' ', 1),
    #Last_Name = (SUBSTRING_INDEX(Customer_Name, ' ', -1)
    Last_Name = TRIM(SUBSTRING(Customer_Name, LENGTH(SUBSTRING_INDEX(Customer_Name, ' ', 1)) + 2));

# Ensuring names are trimmed
UPDATE orders
SET
    Last_Name = TRIM(Last_Name),
    First_Name = TRIM(First_Name);

# Add new columns, substring function applied to order_date and ship_date 
SELECT Order_Date,
	SUBSTRING(Order_Date, 9,2) AS Order_Day,
	SUBSTRING(Order_Date, 6,2) AS Order_Month,
	SUBSTRING(Order_Date, 1,4) AS Order_Year,
	Ship_Date,
    SUBSTRING(Ship_Date, 9,2) AS Ship_Day,
    SUBSTRING(Ship_Date, 6,2) AS Ship_Month,
    SUBSTRING(Ship_Date, 1,4) AS Ship_Year
FROM orders;

ALTER TABLE orders
ADD COLUMN Order_Day VARCHAR(5),
ADD COLUMN Order_Month VARCHAR(5),
ADD COLUMN Order_Year VARCHAR(5),
ADD COLUMN Ship_Day VARCHAR(5),
ADD COLUMN Ship_Month VARCHAR(5),
ADD COLUMN Ship_Year VARCHAR(5);

UPDATE orders
SET
	Order_Day = SUBSTRING(Order_Date, 9,2),
    Order_Month = SUBSTRING(Order_Date, 6,2),
    Order_Year = SUBSTRING(Order_Date, 1,4),
    Ship_Day = SUBSTRING(Ship_Date, 9,2),
    Ship_Month = SUBSTRING(Ship_Date, 6,2),
    Ship_Year = SUBSTRING(Ship_Date, 1,4);

# Rounding: Changing the data presentation and data type in the columns sales and profit in the 'orders' table
UPDATE orders
SET
	Sales = ROUND(Sales, 2),
    Profit = ROUND(Profit, 2);

ALTER TABLE orders
MODIFY COLUMN Sales DECIMAL(8,2),
MODIFY COLUMN Profit DECIMAL(8,2);


# (3) Ensuring data integrity: All Order ID's in the returns table are listed in orders table.
SELECT *
FROM superstore.orders AS o
JOIN superstore.returns AS r
	ON o.Order_ID = r.Order_ID
WHERE o.Order_ID IS NULL;




######## Exploratory Data Analysis (EDA) ########

# (1) Range in Sales Value
SELECT MIN(Sales) AS Min_Sale_Value, MAX(Sales) AS Max_Sale_Value, SUM(Sales) AS Total_Sales
FROM orders;

# (2) Total Number of Sales by Region
SELECT Region, SUM(Sales) As Total_Sales
FROM orders
GROUP BY Region;

# (3) Average Sale by Segment 
SELECT Segment, AVG(Sales) AS Average_Segment_Sales
FROM orders
GROUP BY Segment;

# (4) Average Sale and Total Sale of Items by Category and Sub Category
SELECT Category, Sub_Category, AVG(Sales) AS Average_Sales, SUM(Sales) AS Total_Sales
FROM orders
GROUP BY Category, Sub_Category
ORDER BY AVG(Sales) DESC;


### In SQL, you might see error warnings when running certain queries below. 
### This usually happens because the required database schema—including tables and data—has not been set up on your system. 
### Since the schema is properly configured on my machine, the query runs without issues. 
### To avoid errors, ensure that the necessary database and tables exist using the zip file before executing the query.

# (5) Individual Client Sales Profile - Frequency of Shopping 
SELECT First_Name, Last_Name, Order_Month, Order_Year, Ship_Mode, Category, Sales, Quantity, 
ROW_NUMBER() OVER(PARTITION BY Last_Name ORDER BY Order_Year ASC, Order_Month ASC) AS Running_Shopping_Total
FROM orders
GROUP BY First_Name, Last_Name, Order_Month, Order_Year, Ship_Mode, Category, Sales, Quantity
ORDER BY First_Name, Last_Name DESC, Order_Year ASC, Order_Month ASC;
 
# (6) The Total Money Each Customer has Spent per Transaction and Across Sales
SELECT Customer_Name, Sales, Quantity, SUM(Sales * Quantity) As Total_Sale, SUM(Sales * Quantity) OVER(PARTITION BY Customer_Name) AS Total_Customer_Spend
FROM orders
GROUP BY Customer_Name, Sales, Quantity;
 
# (7) Regional Manager (Person) with the Most Sales and Running Total of Sales for Each Shipping Mode
SELECT o.Ship_Mode, o.Category, o.Sales, o.Profit, p.Region, p.Person, sum(Sales) OVER(PARTITION BY Ship_Mode ORDER BY Person ASC) AS Total_Region_Sales
FROM orders AS o
INNER JOIN people AS p
	ON p.Region = o.Region
ORDER BY 7 DESC;

# (8) Shipment Trends per Year and per Month by Region
SELECT Region, Ship_Year, Ship_Month, COUNT(Ship_Year) AS Shipment_Count
FROM orders
GROUP BY Region, Ship_Year, Ship_Month
ORDER BY Region; 

# (9) Average Monthly Sales Amount by City
SELECT Order_Month, City, AVG(Sales) AS Average_Monthly_City_Sales
FROM orders
GROUP BY Order_Month, City
ORDER BY Order_Month ASC, City ASC;

# (10) Returns by Region 
SELECT o.Row_ID, o.Order_ID, r.Returned, p.Region, ROW_NUMBER() OVER(PARTITION BY p.Region) AS Returns_by_Region
FROM orders AS o
INNER JOIN people AS p
INNER JOIN returns AS r
	ON o.Order_ID = r.Order_ID
    AND p.Region = o.Region
GROUP BY o.Row_ID, o.Order_ID, r.Returned, p.Region;

# (11) Percentage of Return by Region
SELECT p.Region, COUNT(r.Order_ID) AS Returns_Count, COUNT(o.Order_ID) AS Total_Orders_Placed, ROUND((COUNT(r.Order_ID) / COUNT(o.Order_ID)) * 100, 2) AS Return_Rate_Percentage
FROM orders AS o
LEFT JOIN returns AS r
	ON o.Order_ID = r.Order_ID
JOIN people as p
	ON o.Region = p.Region
GROUP BY p.Region;  

# (12) Products with the Highest Return Rate
SELECT o.Product_Name, r.Returned, COUNT(r.Order_ID) AS Returns_Count
FROM orders AS o
INNER JOIN returns AS r
	ON r.Order_ID = o.Order_ID
GROUP BY o.Product_Name, r.Returned
ORDER BY COUNT(r.Order_ID) DESC;

# (13) Highest Profit by Category in Labels 
SELECT Category, Sub_Category, MAX(Sales) AS Highest_Profit, MAX(Profit),
	CASE
		WHEN Profit < 0 THEN 'Loss'
		WHEN Profit < 50 THEN 'Low Profit'
		WHEN Profit BETWEEN 50 AND 100 THEN 'Medium Profit'
		WHEN Profit > 100 THEN 'High Profit'
	END AS Profit_Category
FROM orders
GROUP BY Category, Sub_Category, Profit;

# (14) Profit Composition by Segment and by Category and Sub-Category on the Last Full Year of Sales (2017)
SELECT MIN(Order_Date), MAX(Order_Date)
FROM orders;


SELECT Segment, SUM(Profit) AS Total_Segment_Profit
FROM orders
WHERE Order_Year = (SELECT MAX(Order_Year) FROM orders)
GROUP BY Segment
ORDER BY 2 DESC;


SELECT Category, Sub_Category, SUM(Profit) AS Sub_Category_Profit
FROM orders
WHERE Order_Year = (SELECT MAX(Order_Year) FROM orders)
GROUP BY Category, Sub_Category
ORDER BY 3 DESC;


WITH CategoryProfits AS
(
	SELECT Category, SUM(Profit) AS Total_Category_Profit
    FROM orders
    WHERE Order_Year = (SELECT MAX(Order_Year) FROM orders)
    GROUP BY Category
)
SELECT o.Category, o.Sub_Category, SUM(o.Profit) AS Sub_Category_Profit, ROUND((SUM(o.Profit) / MAX(cp.Total_Category_Profit)) * 100, 2) AS Sub_Contribution_Percentage
FROM orders AS o
JOIN CategoryProfits AS cp
	ON o.Category = cp.Category
WHERE o.Order_Year = (SELECT MAX(Order_Year) FROM orders)
GROUP BY o.Category, o.Sub_Category;


SELECT Order_Year, Segment, Category, Sub_Category, Profit
FROM orders
WHERE Order_Year = (SELECT MAX(Order_Year) FROM orders)
ORDER BY Profit DESC;


# (15) Temporary Table 
CREATE TEMPORARY TABLE Yearly_Category_Sales
SELECT Order_Year, Category, SUM(Sales) AS Sum_of_Sales
FROM orders
GROUP BY Order_Year, Category
ORDER BY Order_Year;

SELECT Order_Year, SUM(Sales)
FROM orders
GROUP BY Order_Year;

# (16) Sales by Category over Years
SELECT 
    ycs1.Order_Year,
    ycs1.Category,
    ycs1.Sum_of_Sales AS Current_Year_Sales,
    ycs2.Sum_of_Sales AS Previous_Year_Sales,
    ROUND(((ycs1.Sum_of_Sales - ycs2.Sum_of_Sales) / ycs2.Sum_of_Sales) * 100, 2) AS Percentage_Difference
FROM 
    (SELECT Order_Year, Category, SUM(Sales) AS Sum_of_Sales
     FROM orders
     GROUP BY Order_Year, Category) AS ycs1
LEFT JOIN 
    (SELECT Order_Year, Category, SUM(Sales) AS Sum_of_Sales
     FROM orders
     GROUP BY Order_Year, Category) AS ycs2
ON 
    ycs1.Category = ycs2.Category 
    AND ycs1.Order_Year = ycs2.Order_Year + 1
ORDER BY 
    ycs1.Order_Year;

# (17) Stored Procedure: Yearly Category Sales Aggregation 
DELIMITER $$
USE superstore $$
CREATE PROCEDURE Yearly_Category_Sales (
	IN input_year INT,
    IN input_category VARCHAR(50)
)
BEGIN 
	IF input_year IS NULL THEN
		SET input_year = (SELECT MAX(Order_Year) FROM orders);
	END IF;
    
    SELECT
		Order_Year,
        Category,
        SUM(Sales) AS Sum_of_Sales
	FROM orders
    WHERE 
		(Order_Year = input_year OR input_year IS NULL) AND
		(Category = input_category OR input_category IS NULL)
    GROUP BY Order_Year, Category
    ORDER BY Order_Year, Category;
END $$
DELIMITER ;

CALL Yearly_Category_Sales(2015, 'Technology');
CALL Yearly_Category_Sales(NULL, NULL);
CALL Yearly_Category_Sales(2024, NULL); # No data beyond 2017, so all values blank.


DROP PROCEDURE Yearly_Category_Sales;
DROP TEMPORARY TABLE Yearly_Category_Sales;

# (18) Overall Profit Margin
SELECT ROUND(SUM(Profit / Sales), 2) * 100 AS Profit_Margin
FROM orders;


    

/* 

SELECT Order_Date, COUNT(Order_Date)
FROM superstore.orders 
WHERE Order_Date LIKE '%01/2015'
GROUP BY Order_Date;

*/


